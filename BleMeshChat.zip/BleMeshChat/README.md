# BLE Mesh Chat — Android Starter Project

Bina internet/mobile-data ke, sirf **Bluetooth Low Energy (BLE)** use karke
nearby devices ke saath chat karne ka starter project. Isme koi server nahi
hai — messages device-se-device, hop-by-hop relay hote hain (flooding
protocol), taaki 2 devices jo direct range mein nahi hain, wo bhi kisi
teesre device ke through connect ho sakein.

## Kaise chalayein

1. Android Studio (Hedgehog ya newer) mein `File → Open` se ye poora
   `BleMeshChat` folder kholo.
2. Gradle sync hone do (pehli baar internet chahiye hoga dependencies
   download karne ke liye).
3. Ek **real Android phone** (API 26+, BLE support wala) USB se connect karo
   — BLE peripheral/advertising mode emulator mein kaam nahi karta, isliye
   real device zaroori hai.
4. Run karo. App Bluetooth permissions maangega — allow karo, aur agar
   Bluetooth OFF hai to ON karo.
5. Isi app ko **doosre phone** pe bhi install karo, dono ka Bluetooth ON
   rakho aur unhe thodi der wait karne do (scan + advertise + connect mein
   kuch second lagte hain). Connect hote hi "Peers: 1" dikhega, phir chat
   type karke bhej sakte ho.
6. 3+ devices ke saath try karoge to relay/mesh behavior dikhega — jo
   devices direct range mein nahi hain unke beech bhi message middle wale
   device se hoke pahunchega (agar TTL khatam nahi hua).

## Ye kaam kaise karta hai (short version)

- Har device ek saath **GATT server** (dusre devices isse connect ho sakte
  hain) aur **GATT client** (ye khud dusre devices dhoond ke connect hota
  hai) dono role play karta hai.
- Ek custom BLE Service UUID advertise hota hai taaki sirf isi app ke
  devices ek-dusre ko pehchanein.
- Har message ke saath ek unique ID aur TTL (hop limit, default 6) hota hai.
  Jab koi message pehli baar milta hai, UI mein dikhaya jaata hai aur turant
  baaki sabhi connected peers ko forward kar diya jaata hai (jisse mila
  usko chhod ke), TTL 1 kam karke. Duplicate messages (already-seen ID)
  ignore ho jaate hain.

Files:
- `BleMeshService.kt` — poora BLE mesh logic (advertise, scan, connect,
  GATT server/client, relay)
- `MeshMessage.kt` — message format + parsing
- `MainActivity.kt` — permissions + simple chat UI

## Jo abhi missing hai (production ke liye aage karna hoga)

- **Connection limits**: BLE typically ek time pe ~4-7 simultaneous
  connections support karta hai per device — abhi code har discovered
  device se connect karne ki koshish karta hai, isse bahut saare devices
  hone par dikkat aa sakti hai. Ek max-connection cap aur "best peers"
  selection logic add karna chahiye.
- **MTU negotiation**: abhi default ~20 byte payload assume ho raha hai;
  lambe messages ke liye `requestMtu()` aur chunking add karni hogi.
- **Retry/backoff**: agar `writeCharacteristic` fail ho jaye to abhi retry
  nahi hota.
- **Persistence**: messages sirf RAM mein hain, app band karne pe chale
  jaate hain — Room database add kar sakte ho history ke liye.
- **iOS version**: ye sirf Android hai. iOS ke liye `CoreBluetooth`
  (`CBPeripheralManager` + `CBCentralManager`) se alag se likhna hoga —
  Android ka BLE GATT aur iOS ka CoreBluetooth wire-compatible hote hain
  (dono raw GATT use karte hain), isliye same Service/Characteristic UUID
  rakh ke iOS app bhi isi mesh mein shaamil ho sakta hai, bas Swift/
  Objective-C mein alag se implement karna padega.
- **Security**: abhi koi encryption/authentication nahi hai — koi bhi isi
  Service UUID advertise karke fake messages inject kar sakta hai. Real
  app ke liye end-to-end encryption (jaise Signal protocol) add karna
  chahiye.
